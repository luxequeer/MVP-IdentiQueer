# identiQueer MVP

This is the MVP for the identiQueer project.