export default function Home() {
  return (
    <main style={{ textAlign: "center", marginTop: "4rem" }}>
      <h1>Welcome to IdentiQueer</h1>
      <p>Your vault of sovereignty begins here.</p>
    </main>
  );
}